**Please, do not create duplicate issues**


### Actual behaviour


### Expected behaviour


### Steps to reproduce


### Configuration

- Plugin version:
- Kanboard version:
- Database type and version:
- PHP version:
- OS:
- Browser:

